> [!IMPORTANT]
> Designed by MatanR and Next MC development team
> 
> **Included packs:**
> MTVehicles - [Github](https://github.com/MTVehicles/MinetopiaVehicles), CustomNamePlates - [Github](https://github.com/Xiao-MoMi/Custom-Nameplates), Weapon Mechanics - [Github](https://github.com/WeaponMechanics/WeaponMechanics)